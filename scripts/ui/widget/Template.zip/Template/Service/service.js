const { cacheRequest } = require('../../../../utils/index');

class Service {
  constructor() {}
}

module.exports = Service;
